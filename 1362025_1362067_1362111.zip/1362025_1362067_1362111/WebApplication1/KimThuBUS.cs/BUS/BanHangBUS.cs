﻿using BanHangConnectionDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KimThuBUS.cs.BUS
{
    public class BanHangBUS
    {
        public static IEnumerable<viewSanPham> DanhSach()
        {
            var DB = new BanHangConnectionDBDB();
            return DB.Query<viewSanPham>("SELECT* FROM viewSanPham");
        }

        public static SanPham GetByID(int id)
        {
            var DB = new BanHangConnectionDBDB();
            return DB.SingleOrDefault<SanPham>("SELECT * FROM SanPham WHERE SP_ID=@0", id);

        }

        public static SanPham ChiTiet(int id)
        {
            var DB = new BanHangConnectionDBDB();
            return DB.Single<SanPham>(id);
        }

        public static IEnumerable<viewSanPham> List()
        {
            var DB = new BanHangConnectionDBDB();
            return DB.Query<viewSanPham>("SELECT* FROM viewSanPham");
        }

        public static void Them(SanPham sanpham)
        {
            new BanHangConnectionDBDB().Insert("SanPham", "SP_ID", sanpham);
        }

        public static SanPham Delete(int id)
        {
            var DB = new BanHangConnectionDBDB();
            return DB.SingleOrDefault<SanPham>("DELETE FROM SanPham WHERE SP_ID=@0", id);
        }

        //Chuc nang Update san pham
        public static void Update(SanPham sanpham)
        {
            new BanHangConnectionDBDB().Update("SanPham", "SP_ID", sanpham);
        }
    }
}
