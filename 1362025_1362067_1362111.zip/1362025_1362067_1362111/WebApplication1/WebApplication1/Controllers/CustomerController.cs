﻿using KimThuBUS.cs.BUS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class CustomerController : Controller
    {
        //
        // GET: /Customer/
        public ActionResult Index()
        {
            return View(BanHangBUS.DanhSach());
        }

        //
        // GET: /Customer/Details/5
        public ActionResult Details(int id)
        {
            return View(BanHangBUS.GetByID(id));
        }

        //
        // GET: /Customer/Create
        
    }
}
