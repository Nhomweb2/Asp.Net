﻿using System.Web.Mvc;

namespace WebApplication1.Areas.AdminBanHang
{
    public class AdminBanHangAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "AdminBanHang";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "AdminBanHang_default",
                "AdminBanHang/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}