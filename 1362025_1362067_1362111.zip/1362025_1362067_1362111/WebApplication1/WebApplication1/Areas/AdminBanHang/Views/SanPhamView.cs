﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication1.Areas.AdminBanHang.Views
{
    public class SanPhamView
    {
        [DataType(DataType.Upload)]
        HttpPostedFileBase ImageUpload { get; set; }
    }
}