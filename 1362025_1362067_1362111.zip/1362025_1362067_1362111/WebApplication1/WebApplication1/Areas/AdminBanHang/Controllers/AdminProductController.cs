﻿using BanHangConnectionDB;
using KimThuBUS.cs.BUS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Areas.AdminBanHang.Controllers
{
    public class AdminProductController : Controller
    {
        //
        // GET: /AdminBanHang/AdminProduct/
        public ActionResult Index()
        {
            return View(BanHangBUS.DanhSach());
        }

        //
        // GET: /AdminBanHang/AdminProduct/Details/5
        public ActionResult Details(int id)
        {
            return View(BanHangBUS.ChiTiet(id));
        }

        //
        // GET: /AdminBanHang/AdminProduct/Create
        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /AdminBanHang/AdminProduct/Create
        [HttpPost]
        public ActionResult Create(SanPham sanpham)
        {
            try
            {
                // TODO: Add insert logic here
                BanHangBUS.Them(sanpham);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /AdminBanHang/AdminProduct/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /AdminBanHang/AdminProduct/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
                BanHangBUS.Update(sanpham);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /AdminBanHang/AdminProduct/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /AdminBanHang/AdminProduct/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                BanHangBUS.Delete(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        public SanPham sanpham { get; set; }
    }
}
